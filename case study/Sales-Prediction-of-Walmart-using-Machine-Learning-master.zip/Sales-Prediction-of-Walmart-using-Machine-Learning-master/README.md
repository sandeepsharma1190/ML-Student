# Sales-Prediction-of-Walmart-using-Machine-Learning
Data Science Project in python to predict the sales for each department using historical markdown data from the Walmart dataset containing data of 45 Walmart stores.
The purpose of this project is to develop a predictive model and find out the sales of each product at a given Walmart store.
This project features a exploratory analysis and my predictive model was primarily based on linear regression

Predict which departments are affected with the holiday markdown events and the extent of impact.

We would also like to create a linear model to find a specific value for Weekly Sales that we want to predict. This line of best fit is intended to approximate further data points based on the line that we find in our training data.
Perform dimensionality reduction to improve prediction error by shrinkage in order to reduce overfitting.
