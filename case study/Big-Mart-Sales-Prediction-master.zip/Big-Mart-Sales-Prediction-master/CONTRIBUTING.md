I contribute this project to all those beginners who want to learn Machine Learning and Data Visualization, Data Analysis etc.
